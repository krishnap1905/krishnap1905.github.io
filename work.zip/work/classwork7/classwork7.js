x=5;
y=6;
// Assignment operators
x = y
console.log(x);
x += y
console.log(x);
x -= y
console.log(x);
x *= y
console.log(x);
x /= y
console.log(x);
x %= y
console.log(x);
// arithemetic operatorrs
x=4;
y=2;
z=x+ y;
console.log(z);
z=x- y;
console.log(z);
z=x* y;
console.log(z);
z=x** y;
console.log(z);
z=x/y;
console.log(z);
z=x% y;
console.log(z);